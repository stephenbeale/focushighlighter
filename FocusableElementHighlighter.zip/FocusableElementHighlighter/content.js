const updateOutline = (state) => {
  const style = document.createElement('style');
  style.id = 'focusHighlighterStyle';
  if (state) {
    style.textContent = `:focus { outline: 6px solid pink !important; }`;
  }
  const existingStyle = document.getElementById('focusHighlighterStyle');
  if (existingStyle) {
    existingStyle.remove();
  }
  document.head.appendChild(style);
};

const getNearestPoints = (rect1, rect2) => {
  const left1 = rect1.left;
  const right1 = rect1.right;
  const top1 = rect1.top;
  const bottom1 = rect1.bottom;

  const left2 = rect2.left;
  const right2 = rect2.right;
  const top2 = rect2.top;
  const bottom2 = rect2.bottom;

  const x1 = Math.max(left1, Math.min(right1, left2 + (right2 - left2) / 2));
  const y1 = Math.max(top1, Math.min(bottom1, top2 + (bottom2 - top2) / 2));

  const x2 = Math.max(left2, Math.min(right2, left1 + (right1 - left1) / 2));
  const y2 = Math.max(top2, Math.min(bottom2, top1 + (bottom1 - top1) / 2));

  return { x1, y1, x2, y2 };
};

const createTrail = (x1, y1, x2, y2) => {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('style', 'position: fixed; top: 0; left: 0; pointer-events: none; z-index: 99999;');
  svg.setAttribute('width', '100%');
  svg.setAttribute('height', '100%');
  document.body.appendChild(svg);

  const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
  line.setAttribute('x1', x1);
  line.setAttribute('y1', y1);
  line.setAttribute('x2', x2);
  line.setAttribute('y2', y2);
  line.setAttribute('stroke', 'pink'); // Changed to pink
  line.setAttribute('stroke-width', '2');
  svg.appendChild(line);

  setTimeout(() => {
    svg.remove();
  }, 250);
};

let lastElement = null;
let focusByMouse = false;

const handleFocus = (event) => {
  if (lastElement && !focusByMouse) {
    const lastRect = lastElement.getBoundingClientRect();
    const currentRect = event.target.getBoundingClientRect();
    const points = getNearestPoints(lastRect, currentRect);
    createTrail(points.x1, points.y1, points.x2, points.y2);
  }
  lastElement = event.target;
  focusByMouse = false;
};

const handleMouseDown = (event) => {
  focusByMouse = true;
};

chrome.storage.sync.get(['activated'], (result) => {
  updateOutline(result.activated);
  if (result.activated) {
    window.addEventListener('focusin', handleFocus, true);
    window.addEventListener('mousedown', handleMouseDown, true);
  } else {
    window.removeEventListener('focusin', handleFocus, true);
    window.removeEventListener('mousedown', handleMouseDown, true);
  }
});

window.addEventListener('toggleFocusHighlighter', (event) => {
  updateOutline(event.detail);
  if (event.detail) {
    window.addEventListener('focusin', handleFocus, true);
    window.addEventListener('mousedown', handleMouseDown, true);
  } else {
    window.removeEventListener('focusin', handleFocus, true);
    window.removeEventListener('mousedown', handleMouseDown, true);
  }
});