const toggleBtn = document.getElementById('toggleBtn');

chrome.storage.sync.get(['activated'], (result) => {
  toggleBtn.textContent = result.activated ? 'Deactivate' : 'Activate';
});

toggleBtn.addEventListener('click', () => {
  chrome.storage.sync.get(['activated'], (result) => {
    const newState = !result.activated;
    chrome.storage.sync.set({ activated: newState }, () => {
      toggleBtn.textContent = newState ? 'Deactivate' : 'Activate';
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach((tab) => {
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            function: () => {
              window.dispatchEvent(new CustomEvent('toggleFocusHighlighter', { detail: newState }));
            },
          });
        });
      });
    });
  });
});
